#!/bin/bash

# GitHub Repository Setup Script
# Run this script after creating your GitHub repository

echo "🚀 Setting up GitHub repository for AWS Infrastructure Templates"
echo ""

# Check if git is initialized
if [ ! -d ".git" ]; then
    echo "❌ Git not initialized. Run 'git init' first."
    exit 1
fi

# Get GitHub repository URL from user
echo "📝 Please enter your GitHub repository URL:"
echo "   Example: https://github.com/yourusername/aws-infrastructure-templates.git"
read -p "Repository URL: " REPO_URL

if [ -z "$REPO_URL" ]; then
    echo "❌ Repository URL is required"
    exit 1
fi

# Add remote origin
echo "🔗 Adding remote origin..."
git remote add origin "$REPO_URL"

# Check if there are any commits
if [ -z "$(git log --oneline 2>/dev/null)" ]; then
    echo "❌ No commits found. Please commit your changes first."
    exit 1
fi

# Push to GitHub
echo "📤 Pushing to GitHub..."
git branch -M main
git push -u origin main

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Successfully pushed to GitHub!"
    echo "🌐 Your repository is now available at:"
    echo "   ${REPO_URL%.git}"
    echo ""
    echo "📋 Next steps:"
    echo "   1. Update the GitHub URLs in your application's DataInitializer.java"
    echo "   2. Replace 'your-org' with your actual GitHub username/organization"
    echo "   3. Add repository description and topics on GitHub"
    echo "   4. Enable GitHub Pages if you want to host documentation"
else
    echo "❌ Failed to push to GitHub. Please check your repository URL and permissions."
    exit 1
fi